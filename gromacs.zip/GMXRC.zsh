# zsh configuration file for Gromacs
# only kept for backwards compatibility
source C:/gmx2019.1/bin/GMXRC.bash
